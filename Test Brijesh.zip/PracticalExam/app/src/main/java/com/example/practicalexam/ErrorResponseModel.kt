package com.example.practicalexam

class ErrorResponseModel (
    val code: String,
    val messages: List<String>,
    val status: String
)
