package com.example.practicalexam.modelclass

class ProfileClass(
    val user: String,
    val userPassword: Int,
    val userText: String,
    val userImg: Int,
        )