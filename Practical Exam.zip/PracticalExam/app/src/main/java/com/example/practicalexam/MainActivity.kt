package com.example.practicalexam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import com.example.practicalexam.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener{
            if (textFocus()){
                val intent = Intent(this,DashboardActivity::class.java)
                startActivity(intent)
                finish()
            }

        }

    }
    private fun textFocus(): Boolean{
        if (binding.etEmailNumber.getText().toString().trim().isEmpty()) {
            binding.etEmailNumber.error = "Username Required"
            binding.etEmailNumber.requestFocus()
            return false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(binding.etEmailNumber.getText().toString().trim())
                .matches())
        {
            binding.etEmailNumber.error = "Username Invalid"
            binding.etEmailNumber.requestFocus()
            return false

        } else if (binding.etPassword.getText().toString().trim().isEmpty()) {
            binding.etPassword.error = "Password Required"
            binding.etPassword.requestFocus()
            return false
        } else if (binding.etPassword.length() < 6) {
            binding.etPassword.error = "Password must be minimum 6 character Required"
            binding.etPassword.requestFocus()
            return false
        } else {
            intent = Intent(this, DashboardActivity::class.java)
            startActivity(intent)
        }
        return true
    }
}