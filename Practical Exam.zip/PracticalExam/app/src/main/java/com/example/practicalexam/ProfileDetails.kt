package com.example.practicalexam

import android.content.Context
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.practicalexam.api.DashboardUtility
import com.example.practicalexam.api.ProfileUtility
import com.example.practicalexam.api.UserService
import com.example.practicalexam.dashboardclass.DashboardResponse
import com.example.practicalexam.databinding.ActivityProfileDetailsBinding
import com.example.practicalexam.profileDetails.DetailsRequest
import com.example.practicalexam.profileDetails.DetailsResponse
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ProfileDetails : AppCompatActivity() {

    lateinit var binding : ActivityProfileDetailsBinding
    var position = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_details)


        var detailsResponse: DetailsResponse


        var connected = false
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        connected = networkInfo != null && networkInfo.isConnected

        if (connected) {

            val header = HashMap<String, String>()
            header["username"] = "52043401091899215064438230613120154429038307144968"
            var detailsRequest = DetailsRequest(
                entity_type_id = "4",
                device_type = "2",
                user_id = "168"

            )

            val dashboardApi: UserService =
                ProfileUtility.getDetailsUser().create(UserService::class.java)

            val callDetails: Call<DetailsResponse> =
                dashboardApi.sendProfileData(header, detailsRequest)

            callDetails.enqueue(object : Callback<DetailsResponse> {
                override fun onResponse(
                    call: Call<DetailsResponse>,
                    response: Response<DetailsResponse>,
                ) {
                    if (response.isSuccessful){

                        detailsResponse  = response.body()!!

                        detailsResponse.data[0].your_name = binding.etFirst.text.toString()
                        detailsResponse.data[0].mobile1 = binding.etPhoneNo.text.toString()
                        detailsResponse.data[0].email = binding.etEmail.text.toString()
                        detailsResponse.data[0].city_name = binding.etContryName.text.toString()

                        Glide.with(this@ProfileDetails)
                            .load(detailsResponse.data[position].small_image_url)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(binding.igProfile)

                    }else{
                        val hashMap: HashMap<Any?, Any?> = HashMap<Any?, Any?>()
                        val gson = Gson()
                        val errorData: ErrorResponseModel = gson.fromJson(
                            response.errorBody()!!.string(),
                            ErrorResponseModel::class.java
                        )
                    }
                }

                override fun onFailure(call: Call<DetailsResponse>, t: Throwable) {
                    Toast.makeText(this@ProfileDetails, "error: " + t.message, Toast.LENGTH_SHORT)
                        .show()
                }

            })
        }

    }
}