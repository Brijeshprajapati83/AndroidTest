package com.example.practicalexam

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.viewpager.widget.ViewPager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.example.practicalexam.adapter.ViewPagerAdapter
import com.example.practicalexam.api.DashboardUtility
import com.example.practicalexam.api.UserService
import com.example.practicalexam.dashboardclass.DashboardRequest
import com.example.practicalexam.dashboardclass.DashboardResponse
import com.example.practicalexam.databinding.ActivityDashboardBinding
import com.google.android.material.tabs.TabLayout
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class DashboardActivity : AppCompatActivity() {

    lateinit var binding: ActivityDashboardBinding
    lateinit var toggle: ActionBarDrawerToggle
    var position = 0

    @SuppressLint("CheckResult")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val list: MutableList<String> = ArrayList()

        list.add("https://picsum.photos/seed/picsum/200/300")
        list.add("https://cdn.maikoapp.com/3d4b/4r2dg/180h.jpg")
        list.add("https://cdn.maikoapp.com/3d4b/4qgko/f200.jpg")

        val viewPagerAdapter = ViewPagerAdapter(this@DashboardActivity, list)
        binding.viewPager.adapter = viewPagerAdapter


        binding.tabHomeIndicator.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                position = tab!!.position
            }

            override fun onTabUnselected(tab: TabLayout.Tab?) {
                position = tab!!.position
            }

            override fun onTabReselected(tab: TabLayout.Tab?) {

            }

        })
        binding.tabHomeIndicator.setupWithViewPager(binding.viewPager)


        binding.apply {
            toggle =
                ActionBarDrawerToggle(this@DashboardActivity,
                    drawerLayout,
                    R.string.open,
                    R.string.close)
            drawerLayout.addDrawerListener(toggle)
            toggle.syncState()

            supportActionBar?.setDisplayHomeAsUpEnabled(true)


            binding.navView.setNavigationItemSelectedListener {
                when (it.itemId) {
                    R.id.itemList -> {
                        val intent = Intent(this@DashboardActivity, ProfileActivity::class.java)
                        startActivity(intent)
                        Toast.makeText(this@DashboardActivity, "success", Toast.LENGTH_SHORT).show()

                    }
                    R.id.itemLogout -> {
                        val intent = Intent(this@DashboardActivity, MainActivity::class.java)
                        startActivity(intent)
                        finish()
                    }

                }
                true
            }
        }
        var dashboardResponse: DashboardResponse


        var connected = false
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        connected = networkInfo != null && networkInfo.isConnected

        if (connected) {

            val header = HashMap<String, String>()
            header["username"] = "52043401091899215064438230613120154429038307144968"
            var dashboardRequest = DashboardRequest(
                entity_type_id = "4",
                device_type = "2",
                user_id = "168"

            )

            val dashboardApi: UserService =
                DashboardUtility.getDashboardUser().create(UserService::class.java)

            val callDashboard: Call<DashboardResponse> =
                dashboardApi.sendDashboardData(header, dashboardRequest)

            callDashboard.enqueue(object : Callback<DashboardResponse> {
                override fun onResponse(
                    call: Call<DashboardResponse>,
                    response: Response<DashboardResponse>,
                ) {
                    if (response.isSuccessful){

                       dashboardResponse  = response.body()!!

                        binding.firstname.text = dashboardResponse.data[position].your_name
                        binding.phoneNo.text = dashboardResponse.data[position].mobile1
                        binding.email.text = dashboardResponse.data[position].email
                        binding.contryName.text = dashboardResponse.data[position].city_name
                        Glide.with(this@DashboardActivity)
                            .load(dashboardResponse.data[position].large_image_url)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(binding.profileImage)

                    }else{
                        val hashMap: HashMap<Any?, Any?> = HashMap<Any?, Any?>()
                        val gson = Gson()
                        val errorData: ErrorResponseModel = gson.fromJson(
                            response.errorBody()!!.string(),
                            ErrorResponseModel::class.java
                        )
                    }
                }

                override fun onFailure(call: Call<DashboardResponse>, t: Throwable) {
                    Toast.makeText(this@DashboardActivity, "error: " + t.message, Toast.LENGTH_SHORT)
                        .show()
                }

            })
        }

        binding.btnEdit.setOnClickListener {
            val intent = Intent(this,ProfileDetails::class.java)
            startActivity(intent)
            finish()
        }

        }
        override fun onOptionsItemSelected(item: MenuItem): Boolean {
            if (toggle.onOptionsItemSelected(item)) {
                true
            }
            return super.onOptionsItemSelected(item)
        }

}