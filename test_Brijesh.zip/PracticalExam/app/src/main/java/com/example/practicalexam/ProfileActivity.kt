package com.example.practicalexam

import android.content.ContentValues
import android.content.ContentValues.TAG
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practicalexam.adapter.ProfileAdapter
import com.example.practicalexam.api.ApiUtility
import com.example.practicalexam.api.UserService
import com.example.practicalexam.databinding.ActivityProfileBinding
import com.example.practicalexam.modelclass.UserData
import com.example.practicalexam.modelclass.UserRequest
import com.example.practicalexam.modelclass.UserResponse
import com.google.gson.Gson
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.Serializable

class ProfileActivity : AppCompatActivity(), ProfileAdapter.OnItemClickListener {

    lateinit var linearLayoutManager: LinearLayoutManager
    lateinit var binding: ActivityProfileBinding
    var recycleViewAdapter: ProfileAdapter? = null
    private var profileList = arrayListOf<UserData>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recycleView.layoutManager = LinearLayoutManager(this)
//
//        profileList = ArrayList()
//        profileList.add(UserData("Brijesh",123456,"Prajapati",R.drawable.header))
//        profileList.add(UserData("Alpesh",123456,"Solanki",R.drawable.header))
//        profileList.add(UserData("Bhargav",123456,"Prajapati",R.drawable.header))
//        profileList.add(UserData("Hiren",123456,"Panchal",R.drawable.header))
//

        var userResponse: UserResponse



        binding.recycleView.setHasFixedSize(true)

        binding.recycleView.setHasFixedSize(true)
        linearLayoutManager = LinearLayoutManager(this)
        binding.recycleView.layoutManager = linearLayoutManager


        var connected = false
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = connectivityManager.activeNetworkInfo
        connected = networkInfo != null && networkInfo.isConnected

        if (connected) {

            val headers = HashMap<String, String>()
            headers["username"] = "92325256115380718591580060965200263538206319290005"
            val userRequest = UserRequest(
                device_type = "2",
                entity_type_id = "3",
                user_id = "91"

            )

            Log.e(TAG, "onCreate: "  + userRequest)


            val userApi: UserService = ApiUtility.getUser().create(UserService::class.java)

            val call: Call<UserResponse> = userApi.sendUserData(headers, userRequest)


            call.enqueue(object : Callback<UserResponse> {

                override fun onResponse(
                    call: Call<UserResponse>,
                    response: Response<UserResponse>,
                ) {


                    if (response.isSuccessful) {


                        userResponse = response.body()!!

                        recycleViewAdapter = ProfileAdapter(this@ProfileActivity,
                            userResponse.data.user_data as ArrayList<UserData>,
                            this@ProfileActivity)

                        binding.recycleView.adapter = recycleViewAdapter

                    } else {
                        val hashMap: HashMap<Any?, Any?> = HashMap<Any?, Any?>()
                        val gson = Gson()
                        val errorData: ErrorResponseModel = gson.fromJson(
                            response.errorBody()!!.string(),
                            ErrorResponseModel::class.java
                        )
                    }
                }

                override fun onFailure(call: Call<UserResponse>, t: Throwable) {
                    Toast.makeText(this@ProfileActivity, "error: " + t.message, Toast.LENGTH_SHORT)
                        .show()

                }
            })
        } else {
            Toast.makeText(this, "No Internet", Toast.LENGTH_SHORT).show()
        }

    }

    override fun onItemClick(userData: UserData, position: Int) {
        val newUserList: ArrayList<UserData> = profileList

        newUserList.remove(userData)
        val intent = Intent(this@ProfileActivity, DashboardActivity::class.java)
        val args = Bundle()
        args.putSerializable("ARRAYLIST", newUserList as Serializable)
        intent.putExtra("BUNDLE", args)
        startActivity(intent)
    }

}
