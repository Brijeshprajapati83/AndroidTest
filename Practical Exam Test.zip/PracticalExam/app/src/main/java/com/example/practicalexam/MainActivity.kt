package com.example.practicalexam

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.practicalexam.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener{
            if (textFocus()){
                val intent = Intent(this,DashboardActivity::class.java)
                startActivity(intent)
                finish()
            }

        }

    }
    private fun textFocus(): Boolean{
        if (binding.etEmailNumber.text.toString().isEmpty()) {
            binding.etEmailNumber.error = "Password And Email Should Not Blank"
            binding.etEmailNumber.requestFocus()
            return false
        } else if (binding.etPassword.text.toString().isEmpty()) {
            binding.etPassword.error = "Password Should Not Blank"
            binding.etPassword.requestFocus()
            return false
        }
        return true
    }
}