package com.example.practicalexam.api

import com.example.practicalexam.modelclass.UserRequest
import com.example.practicalexam.modelclass.UserResponse
import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.HeaderMap
import retrofit2.http.POST

interface UserService {

    @POST("user-list")
    fun sendUserData(
        @HeaderMap headers: Map<String,String>,
        @Body userRequest: UserRequest
    ) : Call<UserResponse>


}